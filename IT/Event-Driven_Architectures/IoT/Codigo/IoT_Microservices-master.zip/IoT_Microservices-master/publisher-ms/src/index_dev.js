const { main } = require('./app/app')

setInterval(main, 60000)
