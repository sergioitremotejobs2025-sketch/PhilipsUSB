const { main } = require('./app/app')

main().then(() => process.exit())
