#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"
#define IP_ADDRESS "172.20.10.3" // This will depend on the WIFI network
#define PORT 80
