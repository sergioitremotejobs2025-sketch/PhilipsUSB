module.exports = {
  MAX_EXPIRATION_TIME: 2592000, // 30 days in seconds
  REFRESH_TOKEN_LENGTH: 256,
  TOKEN_EXPIRATION_TIME: 300, // 5 min in seconds
  TOKEN_SECRET: 'token_secret'
}
