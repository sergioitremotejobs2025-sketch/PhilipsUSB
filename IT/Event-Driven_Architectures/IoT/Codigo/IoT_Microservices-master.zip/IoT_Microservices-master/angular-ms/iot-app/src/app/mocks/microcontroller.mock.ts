export default {
  ip: '192.168.1.50',
  measure: 'Temperatura',
  sensor: 'Grove - Temperature',
  username: 'Rocky'
};
