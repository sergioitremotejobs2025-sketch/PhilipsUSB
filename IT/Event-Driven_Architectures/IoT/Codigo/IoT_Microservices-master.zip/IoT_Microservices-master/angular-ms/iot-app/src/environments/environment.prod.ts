export const environment = {
  ORCHESTRATOR_MS: '192.168.1.222:31600', // '192.168.99.100:31600',
  production: true
}
