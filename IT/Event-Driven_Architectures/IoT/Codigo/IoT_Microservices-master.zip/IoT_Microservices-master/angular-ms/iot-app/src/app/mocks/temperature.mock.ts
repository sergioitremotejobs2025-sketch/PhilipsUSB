export default {
  date: 'Sun, 26 Apr 2020 00:02:34 GMT',
  digital_value: 502,
  ip: '192.168.1.50',
  measure: 'temperature',
  real_value: 24.2,
  sensor: 'Grove - Temperature',
  timestamp: 1587859354001,
  username: 'Rocky'
};
