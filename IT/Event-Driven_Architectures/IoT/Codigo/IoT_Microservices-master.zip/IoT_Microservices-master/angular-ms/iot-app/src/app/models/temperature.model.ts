export interface Temperature {
  date: string,
  digital_value: number,
  ip: string,
  measure: string,
  real_value: number,
  sensor: string,
  timestamp: number,
  username: string
}
