export const environment = {
  ORCHESTRATOR_MS: 'localhost:3000',
  production: false
}
