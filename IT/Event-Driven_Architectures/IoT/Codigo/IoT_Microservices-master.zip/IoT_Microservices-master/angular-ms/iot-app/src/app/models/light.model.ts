export interface Light {
  date: string,
  digital_value: number,
  ip: string,
  measure: string,
  sensor: string,
  timestamp: number,
  username: string
}
