export default {
  end_date: 'Sat, 25 Apr 2020 23:59:33 GMT',
  end_timestamp: 1587859173978,
  init_date: 'Sat, 25 Apr 2020 23:00:34 GMT',
  init_timestamp: 1587855634077,
  max_value: 24.7,
  mean_value: 24.4,
  measure: 'temperature',
  ip: '192.168.1.50',
  min_value: 24.1,
  n_samples: 60,
  sensor: 'Grove - Temperature',
  std_deviation: 0.1,
  time_span: 3539901,
  username: 'Rocky'
};
