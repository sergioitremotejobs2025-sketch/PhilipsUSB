# module-flights-aws-db
AWS database infrastructure for microservices
