# MSD-8: Web APIs are Layered on Top of Microservices

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

