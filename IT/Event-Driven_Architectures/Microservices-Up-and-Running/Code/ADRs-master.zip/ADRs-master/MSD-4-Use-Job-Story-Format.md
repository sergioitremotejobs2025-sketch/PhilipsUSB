# MSD-4: Use the Standard Job Story Format

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

