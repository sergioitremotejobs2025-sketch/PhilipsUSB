# MSD-5: Use PlantUML to Discover Interaction Patterns

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

