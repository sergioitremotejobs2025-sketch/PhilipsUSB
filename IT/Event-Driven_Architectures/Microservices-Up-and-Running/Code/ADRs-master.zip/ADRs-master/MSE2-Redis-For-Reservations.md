# MSE-2: Use Redis to Implement the Reservations Database
Date: 01-08-2020

## Status

Accepted

## Context


## Decision

Use Redis as the data store for reservations to leverage its unique simplicity and flexibility, characteristics fitting for the implementation of this microservice.

## Consequences

