# MSD-3: Use Jobs as the Unit of Analysis

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

