# MSD-9: Use Event Storming Instead of Formal DDD

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

