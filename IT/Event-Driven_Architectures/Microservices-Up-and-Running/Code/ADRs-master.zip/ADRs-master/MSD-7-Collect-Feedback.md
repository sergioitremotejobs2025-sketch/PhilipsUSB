# MSD-7: Colect Feedback on your Service Designs

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

