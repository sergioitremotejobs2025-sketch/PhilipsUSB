# MSE-4: Starting Microservices from Reusable Templates
Date: 01-08-2020

## Status

Accepted

## Context


## Decision

To implement a health-check endpoint, we are going to use the draft RFC and a Node.js implementation of it.

## Consequences

