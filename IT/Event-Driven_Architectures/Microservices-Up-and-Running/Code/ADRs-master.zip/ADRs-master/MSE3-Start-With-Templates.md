# MSE-3: Start Microservices with Reusable Templates
Date: 01-08-2020

## Status

Accepted

## Context


## Decision

Use code templates to jump-start a microservice development in each programming language supported in your ecosystem. Using templates helps with speed of development
without sacrificing quality, and keeps various microservices uniform in their key traits.

## Consequences


