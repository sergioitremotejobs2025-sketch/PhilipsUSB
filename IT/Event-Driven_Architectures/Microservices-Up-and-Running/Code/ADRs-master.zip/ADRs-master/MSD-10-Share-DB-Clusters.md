# MSD-10: Microservices Can Share Physical Database Clusters

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

