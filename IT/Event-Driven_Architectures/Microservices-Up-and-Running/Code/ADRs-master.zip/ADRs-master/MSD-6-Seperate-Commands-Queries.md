# MSD-6: Seperate Service Endpoints into Commands and Queries

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

