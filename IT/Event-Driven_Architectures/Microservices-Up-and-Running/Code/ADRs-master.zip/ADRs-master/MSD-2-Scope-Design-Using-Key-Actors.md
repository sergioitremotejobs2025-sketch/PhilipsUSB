# MSD-2: Scope Design Using Key Actors

Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

