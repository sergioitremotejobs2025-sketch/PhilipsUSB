# MSD-1: Use Standard Design Process
Date: 01-08-2020

## Status

Accepted

## Context


## Decision


## Consequences

