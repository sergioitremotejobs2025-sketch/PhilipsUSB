# INF-5: Use Github for Code Management
Date: 01-08-2020

## Status

Accepted

## Context

We'll need to decide how and where to manage both application and infrastructure code. 

## Decision

We'll use Github to manage code. Github is a poplular code management tool and we expect most readers and implementers to already have an account.

## Consequences

No significant consequences.
