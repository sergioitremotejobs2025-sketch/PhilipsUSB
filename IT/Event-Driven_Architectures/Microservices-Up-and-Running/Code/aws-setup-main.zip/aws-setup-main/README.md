# aws-setup
A collection of AWS setup commands for the Microservices Up &amp; Running book
