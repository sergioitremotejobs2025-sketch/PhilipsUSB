# Event Store
Event Store implementation

API Docs: https://implementing-microservices.github.io/event-store/

## Usage

```
make clean
```

And then the API will be deployed at `http://0.0.0.0:8181`