# infra-staging-env
A Terraform based CI/CD module to build the staging environment (from the book Microservices Up &amp; Running)
