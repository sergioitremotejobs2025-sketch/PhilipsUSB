require('app-module-path').addPath(process.env.HOME_DIR + '/lib');
