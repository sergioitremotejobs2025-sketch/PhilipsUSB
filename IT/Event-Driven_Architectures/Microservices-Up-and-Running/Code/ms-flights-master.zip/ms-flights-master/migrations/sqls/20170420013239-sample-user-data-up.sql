INSERT INTO `users` (`id`, `uuid`, `email`, `password`, `salt`, `created`, `last_updated`)
VALUES
	(1, '5fc0a65e-c67a-4a15-811e-bd24e8e7ef5f', 'first@example.com', '', '', '2017-03-20 01:28:20', '2017-04-18 01:30:58'),
	(2, '229b673c-a2c5-4729-84eb-ff30d42ab133', 'second@example.com', '', '', '2017-04-10 01:28:42', '2017-04-10 01:28:42'),
	(3, '1e687bca-b3b1-486d-a76d-9084a6d2cf37', 'kris@example.co', '', '', '2017-04-15 01:28:59', '2017-04-15 01:28:59'),
	(4, '81f5ed2f-19a1-429a-b529-cfd7ee641b2e', 'jack@example.co.uk', '', '', '2017-04-19 01:29:31', '2017-04-20 01:29:31'),
	(5, '8ca73f19-dca5-4bfe-9d81-6e68fc0f4793', 'molly@example.ca', '', '', '2017-04-20 01:29:47', '2017-04-20 01:30:45');
