'use strict';

var dbm;
var type;
var seed;
var fs = require('fs');
var path = require('path');
var Promise;

/**
  * We receive the dbmigrate dependency from dbmigrate initially.
  * This enables us to not have to rely on NODE_PATH.
  */
exports.setup = function(options, seedLink) {
  dbm = options.dbmigrate;
  type = dbm.dataType;
  seed = seedLink;
  Promise = options.Promise;
};

exports.up = function(db) {
  var filePath = path.join(__dirname, 'sqls', '20170420013239-sample-user-data-up.sql');
  const allowed = ["dev", "qa"];
  if (!allowed.includes(db.internals.argv.env)) {
    console.log(`Environment is not ${allowed}. Skipping ${filePath}`);
    return new Promise( function( resolve, reject ) { resolve(""); });
  }
  
  return new Promise( function( resolve, reject ) {
    fs.readFile(filePath, {encoding: 'utf-8'}, function(err,data){
      if (err) return reject(err);
      console.log('received data: ' + data);

      resolve(data);
    });
  })
  .then(function(data) {
    return db.runSql(data);
  });
};

exports.down = function(db) {
  var filePath = path.join(__dirname, 'sqls', '20170420013239-sample-user-data-down.sql');
  const allowed = ["dev", "qa"];
  if (!allowed.includes(db.internals.argv.env)) {
    console.log(`Environment is not ${allowed}. Skipping ${filePath}`);
    return new Promise( function( resolve, reject ) { resolve(""); });
  }
  
  return new Promise( function( resolve, reject ) {
    fs.readFile(filePath, {encoding: 'utf-8'}, function(err,data){
      if (err) return reject(err);
      console.log('received data: ' + data);

      resolve(data);
    });
  })
  .then(function(data) {
    return db.runSql(data);
  });
};

exports._meta = {
  "version": 1
};
