# module-aws-nginx-ingress
Installs an Nginx Ingress Controller into the MS Up &amp; Running EKS cluster.
