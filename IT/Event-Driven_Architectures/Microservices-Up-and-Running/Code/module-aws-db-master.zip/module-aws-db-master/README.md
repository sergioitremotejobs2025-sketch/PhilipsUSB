# module-aws-db
Provisions Redis and MySQL databases for the book Microservices Up &amp; Running
