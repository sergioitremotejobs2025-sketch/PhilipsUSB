# team-designs
Examples of team designs from the book Microservices Up &amp; Running
