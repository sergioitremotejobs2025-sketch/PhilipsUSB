# module-aws-network
A simple Terraform based AWS network module from the book Microserivces Up and Running
