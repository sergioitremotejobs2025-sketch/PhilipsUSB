# sandbox-env-starter
A starter sandbox environment for the book Microserivces Up &amp; Running

TK add instructions for forking and setting secrets
