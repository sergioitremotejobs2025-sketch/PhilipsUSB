# coding=utf-8

"""
    tests.functional.module
    ~~~~~~~~~~~~~~

    Functional tests
"""
