# coding=utf-8

"""
    tests.unit.module
    ~~~~~~~~~~~~~~

    Unit tests
"""
