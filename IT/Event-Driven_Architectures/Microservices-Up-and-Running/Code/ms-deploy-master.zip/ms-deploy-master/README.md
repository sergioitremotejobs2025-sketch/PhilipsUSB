# ms-deploy
A monorepo for deployment of Microservices. From the O'Reilly book Microservices Up &amp; Running
