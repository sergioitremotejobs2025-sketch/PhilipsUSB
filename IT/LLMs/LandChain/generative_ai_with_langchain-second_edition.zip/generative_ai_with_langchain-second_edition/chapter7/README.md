# Chapter 7 - Software Development and Data Analysis Agents

Please make sure you set up your environment with pip, conda, poetry, or docker! You can set up the keys for the different providers in a `config.py` as recommended in the book. Please check the [setup instructions](../SETUP.md) for dependencies and API keys before you start.

| Section   | File | Colab   | Kaggle   |
|-----------|--------|--------|-----------|
| Examples with code models | [notebook](code_models.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/code_models.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| More examples with code models | [notebook](software_development.ipynb)     | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/software_development.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Code understanding | [notebook](code_understanding.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/code_understanding.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Build a RAG on a documentation website | [notebook](langchain_rag.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/langchain_rag.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Example of data analysis | [notebook](data_science.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/data_science.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Interactive GUI for data analysis  |  [python script](app.py)   |  x      |
| Software development project |  [directory](software_development)   |  x      |



#### 📋 **Kaggle Import Instructions:**
To import any notebook to Kaggle:
1. Click the Kaggle badge above
2. Go to **File** → **Import Notebook** → **GitHub**
3. Paste the corresponding GitHub URL:
   - **Code Models**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/code_models.ipynb`
   - **Software Development**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/software_development.ipynb`
   - **Code Understanding**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/code_understanding.ipynb`
   - **LangChain RAG**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/langchain_rag.ipynb`
   - **Data Science**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter7/data_science.ipynb`
