# Chapter 1 - The Rise of Generative AI: From Language Models to Agents

This is the directory for the code accompanying chapter 1.

Please make sure, you set up your environment with pip, conda, poetry, or docker! You can set up the keys for the different providers in a `config.py` as recommended in the book. Please check the [setup instructions](../SETUP.md) for dependencies and API keys before you start.


| Section | File                             | Colab | Kaggle |
|---------|----------------------------------|-------|--------|
| Tokenization with HuggingFace | [notebook](./tokenization.ipynb) | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter1/tokenization.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |

#### 📋 **Kaggle Import Instructions:**
To import to Kaggle: Click the Kaggle badge → **File** → **Import Notebook** → **GitHub** → Paste: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter1/tokenization.ipynb`


