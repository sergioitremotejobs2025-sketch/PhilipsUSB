# Chapter 8: Evaluation and Testing

This is the directory for the code accompanying chapter 8 on Evaluation and Testing.
Please make sure you set up your environment with pip, conda, poetry, or docker! You can set up the keys for the different providers in a `config.py` as recommended in the book. Please check the [setup instructions](../SETUP.md) for dependencies and API keys before you start.

| Topic | File | Description | Colab | Kaggle |
|-------|------|-------|-------|--------|
| Basic Evaluators | [notebook](basic_evaluators.ipynb) | Demonstrates fundamental evaluation techniques including exact matching, LLM-as-judge approaches (with and without references), criteria evaluation for tone and conciseness, and JSON format validation | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter8/basic_evaluators.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Advanced Evaluation | [notebook](advanced_evaluation.ipynb) | Covers sophisticated evaluation methods such as chain-of-thought reasoning assessment and agent trajectory analysis with custom evaluation functions | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter8/advanced_evaluation.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| LangSmith Evaluation | [notebook](langsmith_evaluation.ipynb) |  Shows how to use LangSmith for creating evaluation datasets, configuring multi-dimensional evaluations, and running benchmarks to systematically assess LLM applications | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter8/langsmith_evaluation.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |

#### 📋 **Kaggle Import Instructions:**
To import any notebook to Kaggle:
1. Click the Kaggle badge above
2. Go to **File** → **Import Notebook** → **GitHub**
3. Paste the corresponding GitHub URL:
   - **Basic Evaluators**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter8/basic_evaluators.ipynb`
   - **Advanced Evaluation**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter8/advanced_evaluation.ipynb`
   - **LangSmith Evaluation**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter8/langsmith_evaluation.ipynb`
