# Chapter 6 - Advanced Applications and Multi-Agent Systems

| Section	| File | Colab	 | Kaggle	|
|-----------|--------|--------|-----------|
| Multiple-choice question-answering agent | [notebook](question_answering.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/question_answering.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| LangGraph streaming | [notebook](streaming.ipynb)     | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/streaming.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Communication between agents | [notebook](communication.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/communication.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Tree-of-thoughts (ToT) agent | [notebook](tot.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/tot.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Cache on LangGraph |  [notebook](cache.ipynb)   | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/cache.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |

#### 📋 **Kaggle Import Instructions:**
To import any notebook to Kaggle:
1. Click the Kaggle badge above
2. Go to **File** → **Import Notebook** → **GitHub**
3. Paste the corresponding GitHub URL:
   - **Question Answering Agent**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/question_answering.ipynb`
   - **LangGraph Streaming**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/streaming.ipynb`
   - **Communication Between Agents**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/communication.ipynb`
   - **Tree-of-Thoughts (ToT) Agent**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/tot.ipynb`
   - **Cache on LangGraph**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter6/cache.ipynb`

Please make sure you set up your environment with pip, conda, poetry, or docker! You can set up the keys for the different providers in a `config.py` as recommended in the book. Please check the [setup instructions](../SETUP.md) for dependencies and API keys before you start.
