# Chapter 2 - First Steps with LangChain
This is the directory for the code accompanying chapter 2.

Please make sure, you set up your environment with pip, conda, poetry, or docker! You can set up the keys for the different providers in a `config.py` as recommended in the book. Please check the [setup instructions](../SETUP.md) for dependencies and API keys before you start.

| Section	                                    | File                           | Colab | Kaggle |
|---------------------------------------------|--------------------------------|-------|--------|
| LLM, and chat models                        | [notebook](chat_models.ipynb)  | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/chat_models.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Prompts                                     | [notebook](prompts.ipynb)      | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/prompts.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| LangChain Common Expression Language (LCEL) | [notebook](LCEL.ipynb)         | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/LCEL.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Running local models                        | [notebook](local_models.ipynb) | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/local_models.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |
| Image generation and understanding          | [notebook](multimodal.ipynb)   | [![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/multimodal.ipynb) | [![Open in Kaggle](https://kaggle.com/static/images/open-in-kaggle.svg)](https://www.kaggle.com/code/new) |

#### **Kaggle Import Instructions:**
To import any notebook to Kaggle:
1. Click the Kaggle badge above
2. Go to **File** → **Import Notebook** → **GitHub**  
3. Paste the corresponding GitHub URL:
   - **Chat Models**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/chat_models.ipynb`
   - **Prompts**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/prompts.ipynb`
   - **LCEL**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/LCEL.ipynb`
   - **Local Models**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/local_models.ipynb`
   - **Multimodal**: `https://github.com/benman1/generative_ai_with_langchain/blob/second_edition/chapter2/multimodal.ipynb`


